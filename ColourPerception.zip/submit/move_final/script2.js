
var node = document.querySelector('#container')
var draging = null
var hour = 0,
  minute = 0,
  second = 0
var millisecond = 0
var int
var timesetter
var standardColors = []
var dragTime = ''
var isFirst = true
var data = {}
var i = 1
var res

var amt = 0


//生成不同深浅的颜色
function _lightenDarkenColor(col, amt) {
  var usePound = false

  if (col[0] == '#') {
    col = col.slice(1)
    usePound = true
  }

  var num = parseInt(col, 16)
  var r = (num >> 16) + amt

  if (r > 255) r = 255
  else if (r < 0) r = 0

  var b = ((num >> 8) & 0x00ff) + amt

  if (b > 255) b = 255
  else if (b < 0) b = 0

  var g = (num & 0x0000ff) + amt

  if (g > 255) g = 255
  else if (g < 0) g = 0

  return (usePound ? '#' : '') + (g | (b << 8) | (r << 16)).toString(16)
}

function _changeColor(col, amt) {
  colorlist = []
  //生成五个不同颜色的色块
  for (var i = 0; i < 5; i++) {
    colorlist[i] = _lightenDarkenColor(col, amt)
    amt = amt + amt
  }

  //将色块打乱顺序
  for (let i = 0; i < colorlist.length; i++) {
    const randomIdx = Math.round(Math.random() * (colorlist.length - 1 - i)) + i; //总之保证生成的数字在5以内
    [colorlist[i], colorlist[randomIdx]] = [colorlist[randomIdx], colorlist[i]]
  }

  console.log('colorlist', colorlist)

  return colorlist
}

function drawBgColor(amt) {
  const colors = _changeColor('#808080', amt)
  standardColors = [...colors].sort((a, b) => a.localeCompare(b))
  // [...colors]将colors拷贝一份新的，因为数组是引用类型，如果直接操作colors，那原本数组里面的内容也会被更改。

  console.log('颜色由深到浅是：', standardColors)

  const eles = document.querySelectorAll('.ele')
  eles.forEach((v, i) => {
    _css(v, 'background', colors[i])
  })
}

//第一次渲染页面
drawBgColor(amt)

//计时器
function start() {
  int = setInterval(function () {
    dragTime = timer()
  })
  return int
}

//计时函数
function timer() {
  millisecond = millisecond + 50
  if (millisecond >= 1000) {
    millisecond = 0
    second = second + 1
  }
  if (second >= 60) {
    second = 0
    minute = minute + 1
  }
  if (minute >= 60) {
    minute = 0
    hour = hour + 1
  }
  return hour + ':' + minute + ':' + second
}

//使用事件委托
node.ondragstart = function (event) {
  //event.target出发事件的元素
  event.dataTransfer.setData('te', event.target.innerText)
  draging = event.target

  //一拖动元素就使用计时器
  if (isFirst) {
    timesetter = start()
  }

  isFirst = false
}

node.ondragover = function (event) {
  //取消默认行为
  event.preventDefault()
  var target = event.target

  if (target.nodeName === 'SPAN') {
    if (target !== draging) {
      //getBoundingClientRect()用于获取某个元素相对于视窗的位置集合
      var targetRect = target.getBoundingClientRect()
      var dragingRect = draging.getBoundingClientRect()
      if (target) {
        if (target.animated) {
          return
        }
      }

      // console.log('_index(draging) ', _index(draging), _index(target))

      if (_index(draging) < _index(target)) {
        //nextSibling 属性可返回某个元素之后紧跟的节点（处于同一树层级中）。
        target.parentNode.insertBefore(draging, target.nextSibling)
      } else {
        target.parentNode.insertBefore(draging, target)
      }
      _animate(dragingRect, draging)
      _animate(targetRect, target)
    }
  }
}



document.querySelector('#button').onclick = function () {
  const currentColors = []
  const eles = document.querySelectorAll('.ele')

  //获取当前页面上的颜色顺序
  for (let index = 0; index < eles.length; index++) {
    const element = eles[index]
    currentColors.push(colorRGBtoHex(element.style.background))
  }

  // eles.forEach(v => {
  //   currentColors.push(colorRGBtoHex(v.style.background))
  // })

  //比较页面上的颜色和标准颜色
  const isEqual = standardColors.toString() === currentColors.toString()
  // console.log(isEqual)

  // console.log('拖拽完成后的颜色顺序和由深到浅标准顺序是否一致？', isEqual ? '一致' : '不一致')

  // console.log('currentColors', currentColors)

  // 计时结束
  clearInterval(timesetter)

  console.log('本次拖拽的时间是:', dragTime)

  // 可以手动更改颜色
  //drawBgColor(amt + 30) 
  console.log('amt1', amt)//前面注释掉之后就amt是初始值了




  data[i] = {}
  data[i]['amt'] = amt;
  data[i]['type'] = isEqual;
  data[i]['time'] = dragTime;
  i = i + 1;
  amt = amt - 1;

  if (amt == 0) {
    res = JSON.stringify(data);
    var blob = new Blob([res], { type: "" });
    saveAs(blob, "./save.json");
    window.alert('done', res)
  }

  drawBgColor(amt)

  console.log('amt2', amt)
  console.log('data', data)


  //这里必须要手动重置，前面clearInterval清除不掉计时器，他会继续接着计时，不会重置
  dragTime = 0
  hour = 0
  minute = 0
  second = 0
  millisecond = 0
  isFirst = true
}

//获取元素在父元素中的index
function _index(el) {
  var index = 0

  if (!el || !el.parentNode) {
    return -1
  }
  //previousElementSibling属性返回指定元素的前一个兄弟元素（相同节点树层中的前一个元素节点）。
  while (el && (el = el.previousElementSibling)) {
    //console.log(el);
    index++
  }

  return index
}

function _animate(prevRect, target) {
  var ms = 300

  if (ms) {
    var currentRect = target.getBoundingClientRect()
    //nodeType 属性返回以数字值返回指定节点的节点类型。1=元素节点  2=属性节点
    if (prevRect.nodeType === 1) {
      prevRect = prevRect.getBoundingClientRect()
    }
    _css(target, 'transition', 'none')
    _css(
      target,
      'transform',
      'translate3d(' +
      (prevRect.left - currentRect.left) +
      'px,' +
      (prevRect.top - currentRect.top) +
      'px,0)'
    )

    target.offsetWidth // 触发重绘

    _css(target, 'transition', 'all ' + ms + 'ms')
    _css(target, 'transform', 'translate3d(0,0,0)')

    clearTimeout(target.animated)
    target.animated = setTimeout(function () {
      _css(target, 'transition', '')
      _css(target, 'transform', '')
      target.animated = false
    }, ms)
  }
}

//给元素添加style
function _css(el, prop, val) {
  var style = el && el.style

  if (style) {
    if (val === void 0) {
      //使用DefaultView属性可以指定打开窗体时所用的视图
      console.log('document.defaultView.getComputedStyle', document.defaultView.getComputedStyle())
      if (document.defaultView && document.defaultView.getComputedStyle) {
        val = document.defaultView.getComputedStyle(el, '')
      } else if (el.currentStyle) {
        val = el.currentStyle
      }

      return prop === void 0 ? val : val[prop]
    } else {
      if (!(prop in style)) {
        prop = '-webkit-' + prop
      }

      style[prop] = val + (typeof val === 'string' ? '' : 'px')
    }
  }
}

function colorRGBtoHex(color) {
  var rgb = color.split(',')
  var r = parseInt(rgb[0].split('(')[1])
  var g = parseInt(rgb[1])
  var b = parseInt(rgb[2].split(')')[0])
  var hex = '#' + ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1)
  return hex
}
