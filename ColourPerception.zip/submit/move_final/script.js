var int
var timesetter
var hour = 0,
    minute = 0,
    second = 0
var millisecond = 0
var dragTime = ''

var amt = [] // 各通道差距的数组
var colorChanged
var colorList = []

//和#808080的亮度差异
var max = 13
var min = -13

//生成仅有亮度差异的颜色
function _lightenDarkenColor(col, amt) {
    var usePound = false

    if (col[0] == '#') {
        col = col.slice(1)
        usePound = true
    }

    var num = parseInt(col, 16)
    var r = (num >> 16) + amt[0]

    if (r > 255) r = 255
    else if (r < 0) r = 0

    var b = ((num >> 8) & 0x00ff) + amt[1]

    if (b > 255) b = 255
    else if (b < 0) b = 0

    var g = (num & 0x0000ff) + amt[2]

    if (g > 255) g = 255
    else if (g < 0) g = 0

    return (usePound ? '#' : '') + (g | (b << 8) | (r << 16)).toString(16)
}

function getRadioValue1() {
    const value = document.getElementsByName('Answer')
    for (var i = 0; i < value.length; i++) {
        if (value[i].checked) {
            return value[i].value
        }
    }
}

function start() {
    int = setInterval(function () {
        dragTime = timer()
    }, 10)
    return int
}

function timer() {
    millisecond = millisecond + 10
    return millisecond
}


/*
function timer() {
    millisecond = millisecond + 10
    if (millisecond >= 1000) {
        millisecond = 0
        second = second + 1
    }
    if (second >= 60) {
        second = 0
        minute = minute + 1
    }
    if (minute >= 60) {
        minute = 0
        hour = hour + 1
    }
    return minute + ':' + second + ':' + millisecond
}*/

document.querySelector('#start').onclick = function () {
    drawColor()
    timesetter = start();
    document.getElementsByClassName('ele')[0].style.display = "block";
    document.getElementsByClassName('ele')[1].style.display = "block";

}

document.querySelector('#end').onclick = function () {
    clearInterval(int)
    console.log('时间是:', dragTime)
    console.log('选择是', getRadioValue1())




    dragTime = 0
    minute = 0
    second = 0
    millisecond = 0
}

function changeColor() {
    var random = Math.floor(Math.random() * (max - min + 1)) + min

    // 亮度、色相、饱和度都改变
    for (let i = 0; i < 3; i++) {
        var x = Math.random()
        if (x < 0.5) {
            amt[i] = 2 //可改，亮度、色相、饱和度改变的差距
        }
        else {
            amt[i] = 0
        }
    }

    // 仅亮度在改变
    // for (let i = 0; i < 3; i++) {
    //     amt[i] = random
    // }
    colorChanged = _lightenDarkenColor('#808080', amt)

    colorlist = ['#808080', colorChanged]

    for (let i = 0; i < 2; i++) {
        const randomIdx = Math.round(Math.random() * (2 - 1 - i)) + i;
        [colorlist[i], colorlist[randomIdx]] = [colorlist[randomIdx], colorlist[i]]
    }
    console.log(colorlist)
}

function drawColor() {
    changeColor()

    const eles = document.querySelectorAll('.ele')
    eles.forEach((v, i) => {
        _css(v, 'background', colorlist[i])
    })
}

//给元素添加style
function _css(el, prop, val) {
    var style = el && el.style

    if (style) {
        if (val === void 0) {
            //使用DefaultView属性可以指定打开窗体时所用的视图
            console.log('document.defaultView.getComputedStyle', document.defaultView.getComputedStyle())
            if (document.defaultView && document.defaultView.getComputedStyle) {
                val = document.defaultView.getComputedStyle(el, '')
            } else if (el.currentStyle) {
                val = el.currentStyle
            }

            return prop === void 0 ? val : val[prop]
        } else {
            if (!(prop in style)) {
                prop = '-webkit-' + prop
            }

            style[prop] = val + (typeof val === 'string' ? '' : 'px')
        }
    }
}